﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Aerolinea
{
    public int IdAerolinea { get; set; }

    public string Nombre { get; set; } = null!;

    public string? PaisOrigen { get; set; }

    public string? Telefono { get; set; }

    public virtual ICollection<Aeronave> Aeronaves { get; set; } = new List<Aeronave>();

    public virtual ICollection<Vuelo> Vuelos { get; set; } = new List<Vuelo>();
}
