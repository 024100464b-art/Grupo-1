﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Asiento
{
    public int IdAsiento { get; set; }

    public string NumeroAsiento { get; set; } = null!;

    public string? Clase { get; set; }

    public int IdAeronave { get; set; }

    public virtual ICollection<Boleto> Boletos { get; set; } = new List<Boleto>();

    public virtual Aeronave IdAeronaveNavigation { get; set; } = null!;
}
