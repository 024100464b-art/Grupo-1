﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Aeropuerto
{
    public int IdAeropuerto { get; set; }

    public string Nombre { get; set; } = null!;

    public string Ciudad { get; set; } = null!;

    public string Pais { get; set; } = null!;

    public string CodigoIata { get; set; } = null!;

    public virtual ICollection<Vuelo> VueloIdAeropuertoDestinoNavigations { get; set; } = new List<Vuelo>();

    public virtual ICollection<Vuelo> VueloIdAeropuertoOrigenNavigations { get; set; } = new List<Vuelo>();
}
