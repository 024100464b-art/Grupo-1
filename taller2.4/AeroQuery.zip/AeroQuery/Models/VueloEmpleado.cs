﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class VueloEmpleado
{
    public int IdVueloEmpleado { get; set; }

    public int IdVuelo { get; set; }

    public int IdEmpleado { get; set; }

    public string? Funcion { get; set; }

    public virtual Empleado IdEmpleadoNavigation { get; set; } = null!;

    public virtual Vuelo IdVueloNavigation { get; set; } = null!;
}
