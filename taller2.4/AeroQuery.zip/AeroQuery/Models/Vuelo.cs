﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Vuelo
{
    public int IdVuelo { get; set; }

    public string CodigoVuelo { get; set; } = null!;

    public DateTime FechaSalida { get; set; }

    public DateTime FechaLlegada { get; set; }

    public string? Estado { get; set; }

    public int IdAerolinea { get; set; }

    public int IdAeronave { get; set; }

    public int IdAeropuertoOrigen { get; set; }

    public int IdAeropuertoDestino { get; set; }

    public int? IdPuerta { get; set; }

    public virtual ICollection<Boleto> Boletos { get; set; } = new List<Boleto>();

    public virtual Aerolinea IdAerolineaNavigation { get; set; } = null!;

    public virtual Aeronave IdAeronaveNavigation { get; set; } = null!;

    public virtual Aeropuerto IdAeropuertoDestinoNavigation { get; set; } = null!;

    public virtual Aeropuerto IdAeropuertoOrigenNavigation { get; set; } = null!;

    public virtual PuertaEmbarque? IdPuertaNavigation { get; set; }

    public virtual ICollection<VueloEmpleado> VueloEmpleados { get; set; } = new List<VueloEmpleado>();
}
