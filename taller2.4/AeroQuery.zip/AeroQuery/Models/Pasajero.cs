﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Pasajero
{
    public int IdPasajero { get; set; }

    public string Nombres { get; set; } = null!;

    public string Apellidos { get; set; } = null!;

    public string TipoDocumento { get; set; } = null!;

    public string NroDocumento { get; set; } = null!;

    public string? Nacionalidad { get; set; }

    public string? Telefono { get; set; }

    public string? Correo { get; set; }

    public virtual ICollection<Boleto> Boletos { get; set; } = new List<Boleto>();
}
