﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Airline
{
    public string IataCode { get; set; } = null!;

    public string? Airline1 { get; set; }

    public virtual ICollection<Flight> Flights { get; set; } = new List<Flight>();
}
