﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class PuertaEmbarque
{
    public int IdPuerta { get; set; }

    public string CodigoPuerta { get; set; } = null!;

    public string? Zona { get; set; }

    public string? Estado { get; set; }

    public virtual ICollection<Vuelo> Vuelos { get; set; } = new List<Vuelo>();
}
