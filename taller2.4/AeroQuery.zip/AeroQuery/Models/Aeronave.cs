﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Aeronave
{
    public int IdAeronave { get; set; }

    public string Matricula { get; set; } = null!;

    public string Modelo { get; set; } = null!;

    public int Capacidad { get; set; }

    public int IdAerolinea { get; set; }

    public virtual ICollection<Asiento> Asientos { get; set; } = new List<Asiento>();

    public virtual Aerolinea IdAerolineaNavigation { get; set; } = null!;

    public virtual ICollection<Vuelo> Vuelos { get; set; } = new List<Vuelo>();
}
