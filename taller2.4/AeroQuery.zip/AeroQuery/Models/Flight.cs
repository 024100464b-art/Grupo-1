﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Flight
{
    public int Id { get; set; }

    public int? Year { get; set; }

    public int? Month { get; set; }

    public int? Day { get; set; }

    public int? DayOfWeek { get; set; }

    public string? Airline { get; set; }

    public int? FlightNumber { get; set; }

    public string? TailNumber { get; set; }

    public string? OriginAirport { get; set; }

    public string? DestinationAirport { get; set; }

    public int? ScheduledDeparture { get; set; }

    public string? DepartureTime { get; set; }

    public string? DepartureDelay { get; set; }

    public string? TaxiOut { get; set; }

    public string? WheelsOff { get; set; }

    public string? ScheduledTime { get; set; }

    public string? ElapsedTime { get; set; }

    public string? AirTime { get; set; }

    public int? Distance { get; set; }

    public string? WheelsOn { get; set; }

    public string? TaxiIn { get; set; }

    public int? ScheduledArrival { get; set; }

    public string? ArrivalTime { get; set; }

    public string? ArrivalDelay { get; set; }

    public int? Diverted { get; set; }

    public int? Cancelled { get; set; }

    public string? CancellationReason { get; set; }

    public string? AirSystemDelay { get; set; }

    public string? SecurityDelay { get; set; }

    public string? AirlineDelay { get; set; }

    public string? LateAircraftDelay { get; set; }

    public string? WeatherDelay { get; set; }

    public virtual Airline? AirlineNavigation { get; set; }

    public virtual Airport? DestinationAirportNavigation { get; set; }

    public virtual Airport? OriginAirportNavigation { get; set; }
}
