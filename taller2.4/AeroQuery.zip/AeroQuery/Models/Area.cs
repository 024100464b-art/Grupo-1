﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Area
{
    public int IdArea { get; set; }

    public string NombreArea { get; set; } = null!;

    public string? Descripcion { get; set; }

    public virtual ICollection<Empleado> Empleados { get; set; } = new List<Empleado>();
}
