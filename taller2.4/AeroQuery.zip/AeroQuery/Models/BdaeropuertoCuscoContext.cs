﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace AeroQuery.Models;

public partial class BdaeropuertoCuscoContext : DbContext
{
    public BdaeropuertoCuscoContext()
    {
    }

    public BdaeropuertoCuscoContext(DbContextOptions<BdaeropuertoCuscoContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Aerolinea> Aerolineas { get; set; }

    public virtual DbSet<Aeronave> Aeronaves { get; set; }

    public virtual DbSet<Aeropuerto> Aeropuertos { get; set; }

    public virtual DbSet<Area> Areas { get; set; }

    public virtual DbSet<Asiento> Asientos { get; set; }

    public virtual DbSet<Boleto> Boletos { get; set; }

    public virtual DbSet<Cargo> Cargos { get; set; }

    public virtual DbSet<Empleado> Empleados { get; set; }

    public virtual DbSet<Equipaje> Equipajes { get; set; }

    public virtual DbSet<Pasajero> Pasajeros { get; set; }

    public virtual DbSet<PuertaEmbarque> PuertaEmbarques { get; set; }

    public virtual DbSet<Vuelo> Vuelos { get; set; }

    public virtual DbSet<VueloEmpleado> VueloEmpleados { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=BDAeropuertoCusco;Trusted_Connection=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Aerolinea>(entity =>
        {
            entity.HasKey(e => e.IdAerolinea).HasName("PK__Aeroline__70493E38812D10D0");

            entity.ToTable("Aerolinea");

            entity.Property(e => e.IdAerolinea).HasColumnName("idAerolinea");
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombre");
            entity.Property(e => e.PaisOrigen)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("paisOrigen");
            entity.Property(e => e.Telefono)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("telefono");
        });

        modelBuilder.Entity<Aeronave>(entity =>
        {
            entity.HasKey(e => e.IdAeronave).HasName("PK__Aeronave__E642D81385A0508A");

            entity.ToTable("Aeronave");

            entity.HasIndex(e => e.Matricula, "UQ__Aeronave__30962D1580F38C14").IsUnique();

            entity.Property(e => e.IdAeronave).HasColumnName("idAeronave");
            entity.Property(e => e.Capacidad).HasColumnName("capacidad");
            entity.Property(e => e.IdAerolinea).HasColumnName("idAerolinea");
            entity.Property(e => e.Matricula)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("matricula");
            entity.Property(e => e.Modelo)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("modelo");

            entity.HasOne(d => d.IdAerolineaNavigation).WithMany(p => p.Aeronaves)
                .HasForeignKey(d => d.IdAerolinea)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Aeronave__idAero__5070F446");
        });

        modelBuilder.Entity<Aeropuerto>(entity =>
        {
            entity.HasKey(e => e.IdAeropuerto).HasName("PK__Aeropuer__12CB9FBF34F3B214");

            entity.ToTable("Aeropuerto");

            entity.HasIndex(e => e.CodigoIata, "UQ__Aeropuer__AA7318F87931ABBA").IsUnique();

            entity.Property(e => e.IdAeropuerto).HasColumnName("idAeropuerto");
            entity.Property(e => e.Ciudad)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("ciudad");
            entity.Property(e => e.CodigoIata)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength()
                .HasColumnName("codigoIATA");
            entity.Property(e => e.Nombre)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("nombre");
            entity.Property(e => e.Pais)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("pais");
        });

        modelBuilder.Entity<Area>(entity =>
        {
            entity.HasKey(e => e.IdArea).HasName("PK__Area__750ECEA40858207E");

            entity.ToTable("Area");

            entity.Property(e => e.IdArea).HasColumnName("idArea");
            entity.Property(e => e.Descripcion)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("descripcion");
            entity.Property(e => e.NombreArea)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("nombreArea");
        });

        modelBuilder.Entity<Asiento>(entity =>
        {
            entity.HasKey(e => e.IdAsiento).HasName("PK__Asiento__F29549309A3FADAA");

            entity.ToTable("Asiento");

            entity.Property(e => e.IdAsiento).HasColumnName("idAsiento");
            entity.Property(e => e.Clase)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasDefaultValue("Económica")
                .HasColumnName("clase");
            entity.Property(e => e.IdAeronave).HasColumnName("idAeronave");
            entity.Property(e => e.NumeroAsiento)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("numeroAsiento");

            entity.HasOne(d => d.IdAeronaveNavigation).WithMany(p => p.Asientos)
                .HasForeignKey(d => d.IdAeronave)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Asiento__idAeron__6383C8BA");
        });

        modelBuilder.Entity<Boleto>(entity =>
        {
            entity.HasKey(e => e.IdBoleto).HasName("PK__Boleto__631437757F12D4E8");

            entity.ToTable("Boleto");

            entity.HasIndex(e => e.IdPasajero, "IX_Boleto_idPasajero");

            entity.HasIndex(e => e.IdVuelo, "IX_Boleto_idVuelo");

            entity.HasIndex(e => e.CodigoBoleto, "UQ__Boleto__D51B75AA5038B822").IsUnique();

            entity.Property(e => e.IdBoleto).HasColumnName("idBoleto");
            entity.Property(e => e.CodigoBoleto)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("codigoBoleto");
            entity.Property(e => e.Estado)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasDefaultValue("Activo")
                .HasColumnName("estado");
            entity.Property(e => e.FechaCompra)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("fechaCompra");
            entity.Property(e => e.IdAsiento).HasColumnName("idAsiento");
            entity.Property(e => e.IdPasajero).HasColumnName("idPasajero");
            entity.Property(e => e.IdVuelo).HasColumnName("idVuelo");
            entity.Property(e => e.Precio)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("precio");

            entity.HasOne(d => d.IdAsientoNavigation).WithMany(p => p.Boletos)
                .HasForeignKey(d => d.IdAsiento)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Boleto__idAsient__6B24EA82");

            entity.HasOne(d => d.IdPasajeroNavigation).WithMany(p => p.Boletos)
                .HasForeignKey(d => d.IdPasajero)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Boleto__idPasaje__693CA210");

            entity.HasOne(d => d.IdVueloNavigation).WithMany(p => p.Boletos)
                .HasForeignKey(d => d.IdVuelo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Boleto__idVuelo__6A30C649");
        });

        modelBuilder.Entity<Cargo>(entity =>
        {
            entity.HasKey(e => e.IdCargo).HasName("PK__Cargo__3D0E29B88BC014FF");

            entity.ToTable("Cargo");

            entity.Property(e => e.IdCargo).HasColumnName("idCargo");
            entity.Property(e => e.Descripcion)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("descripcion");
            entity.Property(e => e.NombreCargo)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("nombreCargo");
        });

        modelBuilder.Entity<Empleado>(entity =>
        {
            entity.HasKey(e => e.IdEmpleado).HasName("PK__Empleado__5295297C55C1BE13");

            entity.ToTable("Empleado");

            entity.HasIndex(e => e.Dni, "UQ__Empleado__D87608A7B2DA87BB").IsUnique();

            entity.Property(e => e.IdEmpleado).HasColumnName("idEmpleado");
            entity.Property(e => e.Apellidos)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("apellidos");
            entity.Property(e => e.Correo)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("correo");
            entity.Property(e => e.Dni)
                .HasMaxLength(8)
                .IsUnicode(false)
                .IsFixedLength()
                .HasColumnName("dni");
            entity.Property(e => e.IdArea).HasColumnName("idArea");
            entity.Property(e => e.IdCargo).HasColumnName("idCargo");
            entity.Property(e => e.Nombres)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("nombres");
            entity.Property(e => e.Telefono)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("telefono");
            entity.Property(e => e.Turno)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("turno");

            entity.HasOne(d => d.IdAreaNavigation).WithMany(p => p.Empleados)
                .HasForeignKey(d => d.IdArea)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Empleado__idArea__787EE5A0");

            entity.HasOne(d => d.IdCargoNavigation).WithMany(p => p.Empleados)
                .HasForeignKey(d => d.IdCargo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Empleado__idCarg__778AC167");
        });

        modelBuilder.Entity<Equipaje>(entity =>
        {
            entity.HasKey(e => e.IdEquipaje).HasName("PK__Equipaje__735607F8DADCACC3");

            entity.ToTable("Equipaje");

            entity.HasIndex(e => e.IdBoleto, "IX_Equipaje_idBoleto");

            entity.HasIndex(e => e.CodigoEquipaje, "UQ__Equipaje__DF0084DE80E0BAE0").IsUnique();

            entity.Property(e => e.IdEquipaje).HasColumnName("idEquipaje");
            entity.Property(e => e.CodigoEquipaje)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("codigoEquipaje");
            entity.Property(e => e.Estado)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasDefaultValue("Registrado")
                .HasColumnName("estado");
            entity.Property(e => e.IdBoleto).HasColumnName("idBoleto");
            entity.Property(e => e.Peso)
                .HasColumnType("decimal(6, 2)")
                .HasColumnName("peso");

            entity.HasOne(d => d.IdBoletoNavigation).WithMany(p => p.Equipajes)
                .HasForeignKey(d => d.IdBoleto)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Equipaje__idBole__6FE99F9F");
        });

        modelBuilder.Entity<Pasajero>(entity =>
        {
            entity.HasKey(e => e.IdPasajero).HasName("PK__Pasajero__D2D75CAD502162F8");

            entity.ToTable("Pasajero");

            entity.HasIndex(e => e.NroDocumento, "UQ__Pasajero__A0EE94AFFBCBFE83").IsUnique();

            entity.Property(e => e.IdPasajero).HasColumnName("idPasajero");
            entity.Property(e => e.Apellidos)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("apellidos");
            entity.Property(e => e.Correo)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("correo");
            entity.Property(e => e.Nacionalidad)
                .HasMaxLength(60)
                .IsUnicode(false)
                .HasColumnName("nacionalidad");
            entity.Property(e => e.Nombres)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("nombres");
            entity.Property(e => e.NroDocumento)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("nroDocumento");
            entity.Property(e => e.Telefono)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("telefono");
            entity.Property(e => e.TipoDocumento)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("tipoDocumento");
        });

        modelBuilder.Entity<PuertaEmbarque>(entity =>
        {
            entity.HasKey(e => e.IdPuerta).HasName("PK__PuertaEm__ADB4891E1C5BF218");

            entity.ToTable("PuertaEmbarque");

            entity.HasIndex(e => e.CodigoPuerta, "UQ__PuertaEm__16D6493DAB14A48C").IsUnique();

            entity.Property(e => e.IdPuerta).HasColumnName("idPuerta");
            entity.Property(e => e.CodigoPuerta)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("codigoPuerta");
            entity.Property(e => e.Estado)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasDefaultValue("Disponible")
                .HasColumnName("estado");
            entity.Property(e => e.Zona)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("zona");
        });

        modelBuilder.Entity<Vuelo>(entity =>
        {
            entity.HasKey(e => e.IdVuelo).HasName("PK__Vuelo__8FC0EFB7A87CB418");

            entity.ToTable("Vuelo");

            entity.HasIndex(e => e.FechaSalida, "IX_Vuelo_fechaSalida");

            entity.HasIndex(e => e.IdAerolinea, "IX_Vuelo_idAerolinea");

            entity.HasIndex(e => e.IdAeronave, "IX_Vuelo_idAeronave");

            entity.HasIndex(e => e.CodigoVuelo, "UQ__Vuelo__780EBD305A6262F1").IsUnique();

            entity.Property(e => e.IdVuelo).HasColumnName("idVuelo");
            entity.Property(e => e.CodigoVuelo)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("codigoVuelo");
            entity.Property(e => e.Estado)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasDefaultValue("Programado")
                .HasColumnName("estado");
            entity.Property(e => e.FechaLlegada)
                .HasColumnType("datetime")
                .HasColumnName("fechaLlegada");
            entity.Property(e => e.FechaSalida)
                .HasColumnType("datetime")
                .HasColumnName("fechaSalida");
            entity.Property(e => e.IdAerolinea).HasColumnName("idAerolinea");
            entity.Property(e => e.IdAeronave).HasColumnName("idAeronave");
            entity.Property(e => e.IdAeropuertoDestino).HasColumnName("idAeropuertoDestino");
            entity.Property(e => e.IdAeropuertoOrigen).HasColumnName("idAeropuertoOrigen");
            entity.Property(e => e.IdPuerta).HasColumnName("idPuerta");

            entity.HasOne(d => d.IdAerolineaNavigation).WithMany(p => p.Vuelos)
                .HasForeignKey(d => d.IdAerolinea)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Vuelo__idAerolin__59063A47");

            entity.HasOne(d => d.IdAeronaveNavigation).WithMany(p => p.Vuelos)
                .HasForeignKey(d => d.IdAeronave)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Vuelo__idAeronav__59FA5E80");

            entity.HasOne(d => d.IdAeropuertoDestinoNavigation).WithMany(p => p.VueloIdAeropuertoDestinoNavigations)
                .HasForeignKey(d => d.IdAeropuertoDestino)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Vuelo__idAeropue__5BE2A6F2");

            entity.HasOne(d => d.IdAeropuertoOrigenNavigation).WithMany(p => p.VueloIdAeropuertoOrigenNavigations)
                .HasForeignKey(d => d.IdAeropuertoOrigen)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Vuelo__idAeropue__5AEE82B9");

            entity.HasOne(d => d.IdPuertaNavigation).WithMany(p => p.Vuelos)
                .HasForeignKey(d => d.IdPuerta)
                .HasConstraintName("FK__Vuelo__idPuerta__5CD6CB2B");
        });

        modelBuilder.Entity<VueloEmpleado>(entity =>
        {
            entity.HasKey(e => e.IdVueloEmpleado).HasName("PK__VueloEmp__06AE62433A769594");

            entity.ToTable("VueloEmpleado");

            entity.HasIndex(e => e.IdEmpleado, "IX_VueloEmpleado_idEmpleado");

            entity.HasIndex(e => e.IdVuelo, "IX_VueloEmpleado_idVuelo");

            entity.Property(e => e.IdVueloEmpleado).HasColumnName("idVueloEmpleado");
            entity.Property(e => e.Funcion)
                .HasMaxLength(80)
                .IsUnicode(false)
                .HasColumnName("funcion");
            entity.Property(e => e.IdEmpleado).HasColumnName("idEmpleado");
            entity.Property(e => e.IdVuelo).HasColumnName("idVuelo");

            entity.HasOne(d => d.IdEmpleadoNavigation).WithMany(p => p.VueloEmpleados)
                .HasForeignKey(d => d.IdEmpleado)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__VueloEmpl__idEmp__7C4F7684");

            entity.HasOne(d => d.IdVueloNavigation).WithMany(p => p.VueloEmpleados)
                .HasForeignKey(d => d.IdVuelo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__VueloEmpl__idVue__7B5B524B");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
