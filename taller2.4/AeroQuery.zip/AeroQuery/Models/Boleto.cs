﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Boleto
{
    public int IdBoleto { get; set; }

    public string CodigoBoleto { get; set; } = null!;

    public DateTime? FechaCompra { get; set; }

    public decimal Precio { get; set; }

    public string? Estado { get; set; }

    public int IdPasajero { get; set; }

    public int IdVuelo { get; set; }

    public int IdAsiento { get; set; }

    public virtual ICollection<Equipaje> Equipajes { get; set; } = new List<Equipaje>();

    public virtual Asiento IdAsientoNavigation { get; set; } = null!;

    public virtual Pasajero IdPasajeroNavigation { get; set; } = null!;

    public virtual Vuelo IdVueloNavigation { get; set; } = null!;
}
