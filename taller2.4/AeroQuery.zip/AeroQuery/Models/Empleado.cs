﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Empleado
{
    public int IdEmpleado { get; set; }

    public string Nombres { get; set; } = null!;

    public string Apellidos { get; set; } = null!;

    public string Dni { get; set; } = null!;

    public string? Telefono { get; set; }

    public string? Correo { get; set; }

    public string? Turno { get; set; }

    public int IdCargo { get; set; }

    public int IdArea { get; set; }

    public virtual Area IdAreaNavigation { get; set; } = null!;

    public virtual Cargo IdCargoNavigation { get; set; } = null!;

    public virtual ICollection<VueloEmpleado> VueloEmpleados { get; set; } = new List<VueloEmpleado>();
}
