﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace AeroQuery.Models;

public partial class AeropuertoContext : DbContext
{
    public AeropuertoContext()
    {
    }

    public AeropuertoContext(DbContextOptions<AeropuertoContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Airline> Airlines { get; set; }

    public virtual DbSet<Airport> Airports { get; set; }

    public virtual DbSet<Flight> Flights { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=Aeropuerto;Trusted_Connection=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Airline>(entity =>
        {
            entity.HasKey(e => e.IataCode).HasName("PK__Airlines__B78B655B2805239B");

            entity.Property(e => e.IataCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("IATA_CODE");
            entity.Property(e => e.Airline1)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("AIRLINE");
        });

        modelBuilder.Entity<Airport>(entity =>
        {
            entity.HasKey(e => e.IataCode).HasName("PK__Airports__B78B655B7672FFFD");

            entity.Property(e => e.IataCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("IATA_CODE");
            entity.Property(e => e.Airport1)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("AIRPORT");
            entity.Property(e => e.City)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("CITY");
            entity.Property(e => e.Country)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("COUNTRY");
            entity.Property(e => e.Latitude).HasColumnName("LATITUDE");
            entity.Property(e => e.Longitude).HasColumnName("LONGITUDE");
            entity.Property(e => e.State)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("STATE");
        });

        modelBuilder.Entity<Flight>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Flights__3214EC0700E7D7F4");

            entity.Property(e => e.AirSystemDelay)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("AIR_SYSTEM_DELAY");
            entity.Property(e => e.AirTime)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("AIR_TIME");
            entity.Property(e => e.Airline)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("AIRLINE");
            entity.Property(e => e.AirlineDelay)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("AIRLINE_DELAY");
            entity.Property(e => e.ArrivalDelay)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("ARRIVAL_DELAY");
            entity.Property(e => e.ArrivalTime)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("ARRIVAL_TIME");
            entity.Property(e => e.CancellationReason)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("CANCELLATION_REASON");
            entity.Property(e => e.Cancelled).HasColumnName("CANCELLED");
            entity.Property(e => e.Day).HasColumnName("DAY");
            entity.Property(e => e.DayOfWeek).HasColumnName("DAY_OF_WEEK");
            entity.Property(e => e.DepartureDelay)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("DEPARTURE_DELAY");
            entity.Property(e => e.DepartureTime)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("DEPARTURE_TIME");
            entity.Property(e => e.DestinationAirport)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("DESTINATION_AIRPORT");
            entity.Property(e => e.Distance).HasColumnName("DISTANCE");
            entity.Property(e => e.Diverted).HasColumnName("DIVERTED");
            entity.Property(e => e.ElapsedTime)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("ELAPSED_TIME");
            entity.Property(e => e.FlightNumber).HasColumnName("FLIGHT_NUMBER");
            entity.Property(e => e.LateAircraftDelay)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("LATE_AIRCRAFT_DELAY");
            entity.Property(e => e.Month).HasColumnName("MONTH");
            entity.Property(e => e.OriginAirport)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("ORIGIN_AIRPORT");
            entity.Property(e => e.ScheduledArrival).HasColumnName("SCHEDULED_ARRIVAL");
            entity.Property(e => e.ScheduledDeparture).HasColumnName("SCHEDULED_DEPARTURE");
            entity.Property(e => e.ScheduledTime)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("SCHEDULED_TIME");
            entity.Property(e => e.SecurityDelay)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("SECURITY_DELAY");
            entity.Property(e => e.TailNumber)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("TAIL_NUMBER");
            entity.Property(e => e.TaxiIn)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("TAXI_IN");
            entity.Property(e => e.TaxiOut)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("TAXI_OUT");
            entity.Property(e => e.WeatherDelay)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("WEATHER_DELAY");
            entity.Property(e => e.WheelsOff)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("WHEELS_OFF");
            entity.Property(e => e.WheelsOn)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("WHEELS_ON");
            entity.Property(e => e.Year).HasColumnName("YEAR");

            entity.HasOne(d => d.AirlineNavigation).WithMany(p => p.Flights)
                .HasForeignKey(d => d.Airline)
                .HasConstraintName("FK_Flights_Airline");

            entity.HasOne(d => d.DestinationAirportNavigation).WithMany(p => p.FlightDestinationAirportNavigations)
                .HasForeignKey(d => d.DestinationAirport)
                .HasConstraintName("FK_Flights_DestinationAirport");

            entity.HasOne(d => d.OriginAirportNavigation).WithMany(p => p.FlightOriginAirportNavigations)
                .HasForeignKey(d => d.OriginAirport)
                .HasConstraintName("FK_Flights_OriginAirport");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
