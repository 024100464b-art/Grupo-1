﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Airport
{
    public string IataCode { get; set; } = null!;

    public string? Airport1 { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public string? Country { get; set; }

    public double? Latitude { get; set; }

    public double? Longitude { get; set; }

    public virtual ICollection<Flight> FlightDestinationAirportNavigations { get; set; } = new List<Flight>();

    public virtual ICollection<Flight> FlightOriginAirportNavigations { get; set; } = new List<Flight>();
}
