﻿using System;
using System.Collections.Generic;

namespace AeroQuery.Models;

public partial class Equipaje
{
    public int IdEquipaje { get; set; }

    public string CodigoEquipaje { get; set; } = null!;

    public decimal Peso { get; set; }

    public string? Estado { get; set; }

    public int IdBoleto { get; set; }

    public virtual Boleto IdBoletoNavigation { get; set; } = null!;
}
