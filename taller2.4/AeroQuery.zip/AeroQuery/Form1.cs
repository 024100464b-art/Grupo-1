using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using AeroQuery.Models;

namespace AeroQuery;

public partial class Form1 : Form
{
    private Panel panelMenu;
    private Panel panelContent;
    private Panel panelTopBar;
    private DataGridView dgvResults;
    private Label lblTitle;
    private TextBox txtSearch;
    private Button btnSearch;
    private Panel searchContainer;
    private int currentQueryId = 0;

    public Form1()
    {
        InitializeComponent();
        SetupModernUI();
    }

    private void SetupModernUI()
    {
        // 1. Configuración Principal
        this.Text = "AeroQuery Cusco - Dashboard Ejecutivo";
        this.Size = new Size(1300, 800);
        this.StartPosition = FormStartPosition.CenterScreen;
        this.BackColor = Color.FromArgb(240, 242, 245);
        this.Font = new Font("Segoe UI", 10);

        // 2. Menú Lateral
        panelMenu = new Panel { Dock = DockStyle.Left, Width = 340, BackColor = Color.FromArgb(33, 37, 41) };
        
        Label lblLogo = new Label { 
            Text = "✈ AEROQUERY CUSCO", 
            ForeColor = Color.White, 
            Font = new Font("Segoe UI", 16, FontStyle.Bold),
            Dock = DockStyle.Top,
            Height = 100,
            TextAlign = ContentAlignment.MiddleCenter
        };

        // Botones del menú
        string[] queryTitles = {
            "1. Listar Aeropuertos",
            "2. Buscar Pasajero (DNI)",
            "3. Vuelos, Aerolíneas y Aeronaves",
            "4. Boletos Activos y Pasajeros",
            "5. Personal y Áreas de Trabajo",
            "6. Vuelos Cancelados/Retrasados",
            "7. Recaudación por Aerolínea ($)",
            "8. Rutas más Demandadas",
            "9. Peso de Equipaje por Vuelo",
            "10. Dashboard de Ocupación"
        };

        // CORRECCIÓN: Agregar los botones en orden inverso y usar BringToFront para que se apilen correctamente
        for (int i = queryTitles.Length - 1; i >= 0; i--) 
        {
            Button btn = new Button {
                Text = "  " + queryTitles[i],
                Dock = DockStyle.Top,
                Height = 55,
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.LightGray,
                BackColor = Color.FromArgb(33, 37, 41),
                TextAlign = ContentAlignment.MiddleLeft,
                Tag = i + 1,
                Cursor = Cursors.Hand,
                Font = new Font("Segoe UI", 11) 
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += MenuButton_Click;
            panelMenu.Controls.Add(btn);
            btn.BringToFront(); // Apila cada botón encima del anterior
        }
        
        // Agregar el logo al final y traerlo al frente para que quede hasta arriba
        panelMenu.Controls.Add(lblLogo);
        lblLogo.BringToFront();

        this.Controls.Add(panelMenu);

        // 3. Panel Central
        panelContent = new Panel { Dock = DockStyle.Fill };

        // 3.1 Barra Superior
        panelTopBar = new Panel { Dock = DockStyle.Top, Height = 100, BackColor = Color.White };
        
        lblTitle = new Label {
            Text = "Bienvenido. Seleccione una consulta en el menú.",
            Font = new Font("Segoe UI", 14, FontStyle.Bold),
            ForeColor = Color.FromArgb(50, 50, 50),
            AutoSize = true,
            Location = new Point(30, 35)
        };
        panelTopBar.Controls.Add(lblTitle);

        // Contenedor de Búsqueda (Anclado a la derecha para evitar que choque con el título)
        searchContainer = new Panel {
            Size = new Size(350, 40),
            Visible = false,
            Anchor = AnchorStyles.Top | AnchorStyles.Right // CORRECCIÓN: Anclado a la derecha
        };
        searchContainer.Location = new Point(panelTopBar.Width - 380, 30);
        
        Label lblSearch = new Label {
            Text = "DNI:", Location = new Point(0, 5), AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Bold)
        };
        txtSearch = new TextBox {
            Location = new Point(50, 3), Width = 180, Font = new Font("Segoe UI", 12), BorderStyle = BorderStyle.FixedSingle
        };
        btnSearch = new Button {
            Text = "Buscar", Location = new Point(240, 2), Width = 90, Height = 32,
            BackColor = Color.FromArgb(0, 123, 255), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Cursor = Cursors.Hand
        };
        btnSearch.FlatAppearance.BorderSize = 0;
        btnSearch.Click += BtnSearch_Click;
        
        searchContainer.Controls.Add(lblSearch);
        searchContainer.Controls.Add(txtSearch);
        searchContainer.Controls.Add(btnSearch);
        
        panelTopBar.Controls.Add(searchContainer);
        panelContent.Controls.Add(panelTopBar);

        // 3.2 Tabla de Datos
        dgvResults = new DataGridView {
            Dock = DockStyle.Fill,
            BackgroundColor = Color.FromArgb(240, 242, 245),
            BorderStyle = BorderStyle.None,
            AllowUserToAddRows = false,
            ReadOnly = true,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            RowHeadersVisible = false,
            // CORRECCIÓN: Mostrar Scroll Horizontal usando DisplayedCells en vez de Fill que aplastaba todo
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells,
            CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
            GridColor = Color.LightGray,
            EnableHeadersVisualStyles = false,
            ScrollBars = ScrollBars.Both
        };
        
        dgvResults.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(245, 245, 245);
        dgvResults.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
        dgvResults.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11, FontStyle.Bold);
        dgvResults.ColumnHeadersHeight = 50;
        
        dgvResults.AlternatingRowsDefaultCellStyle.BackColor = Color.White;
        dgvResults.RowsDefaultCellStyle.BackColor = Color.FromArgb(249, 249, 249);
        dgvResults.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(204, 229, 255);
        dgvResults.RowsDefaultCellStyle.SelectionForeColor = Color.Black;
        dgvResults.RowTemplate.Height = 35;

        Panel paddingPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20) };
        paddingPanel.Controls.Add(dgvResults);
        
        panelContent.Controls.Add(paddingPanel);
        paddingPanel.BringToFront(); // Evita que la tabla tape la barra superior

        this.Controls.Add(panelContent);
        
        // CORRECCIÓN CRÍTICA DE SOLAPAMIENTO:
        // Asegura que el panelContent (Dock Fill) respete el espacio del panelMenu (Dock Left)
        panelContent.BringToFront(); 
    }

    private void MenuButton_Click(object sender, EventArgs e)
    {
        Button clickedBtn = sender as Button;
        currentQueryId = (int)clickedBtn.Tag;
        
        lblTitle.Text = clickedBtn.Text.Trim();

        foreach (Control ctrl in panelMenu.Controls)
        {
            if (ctrl is Button b)
            {
                b.BackColor = Color.FromArgb(33, 37, 41);
                b.ForeColor = Color.LightGray;
            }
        }
        clickedBtn.BackColor = Color.FromArgb(0, 123, 255);
        clickedBtn.ForeColor = Color.White;

        if (currentQueryId == 2)
        {
            searchContainer.Visible = true;
            txtSearch.Text = "70000005"; 
            txtSearch.Focus();
        }
        else
        {
            searchContainer.Visible = false;
            ExecuteQuery(); 
        }
    }

    private void BtnSearch_Click(object sender, EventArgs e)
    {
        ExecuteQuery();
    }

    private void ExecuteQuery()
    {
        Cursor.Current = Cursors.WaitCursor;
        dgvResults.DataSource = null;

        try
        {
            using (var context = new BdaeropuertoCuscoContext())
            {
                switch (currentQueryId)
                {
                    case 1:
                        dgvResults.DataSource = context.Aeropuertos.ToList();
                        break;
                    case 2:
                        string dni = txtSearch.Text.Trim();
                        dgvResults.DataSource = context.Pasajeros.Where(p => p.NroDocumento == dni).ToList();
                        break;
                    case 3:
                        var q3 = context.Vuelos
                            .Include(v => v.IdAerolineaNavigation)
                            .Include(v => v.IdAeronaveNavigation)
                            .Select(v => new {
                                v.CodigoVuelo,
                                Aerolinea = v.IdAerolineaNavigation.Nombre,
                                ModeloAvion = v.IdAeronaveNavigation.Modelo,
                                v.Estado,
                                v.FechaSalida
                            }).Take(100).ToList();
                        dgvResults.DataSource = q3;
                        break;
                    case 4:
                        var q4 = context.Boletos
                            .Include(b => b.IdPasajeroNavigation)
                            .Include(b => b.IdVueloNavigation)
                            .Where(b => b.Estado == "Activo")
                            .Select(b => new {
                                b.CodigoBoleto,
                                Pasajero = b.IdPasajeroNavigation.Nombres + " " + b.IdPasajeroNavigation.Apellidos,
                                DNI = b.IdPasajeroNavigation.NroDocumento,
                                Vuelo = b.IdVueloNavigation.CodigoVuelo,
                                b.Precio
                            }).Take(100).ToList();
                        dgvResults.DataSource = q4;
                        break;
                    case 5:
                        var q5 = context.Empleados
                            .Include(e => e.IdCargoNavigation)
                            .Include(e => e.IdAreaNavigation)
                            .Select(e => new {
                                e.Nombres,
                                e.Apellidos,
                                e.Turno,
                                Cargo = e.IdCargoNavigation.NombreCargo,
                                AreaTrabajo = e.IdAreaNavigation.NombreArea
                            }).Take(100).ToList();
                        dgvResults.DataSource = q5;
                        break;
                    case 6:
                        var q6 = context.Vuelos
                            .Include(v => v.IdAeropuertoDestinoNavigation)
                            .Where(v => v.Estado == "Cancelado" || v.Estado == "Retrasado")
                            .Select(v => new {
                                v.CodigoVuelo,
                                v.Estado,
                                Fecha = v.FechaSalida,
                                DestinoAfectado = v.IdAeropuertoDestinoNavigation.Ciudad + " (" + v.IdAeropuertoDestinoNavigation.CodigoIata + ")"
                            }).ToList();
                        dgvResults.DataSource = q6;
                        break;
                    case 7:
                        var q7 = context.Boletos
                            .Include(b => b.IdVueloNavigation)
                            .ThenInclude(v => v.IdAerolineaNavigation)
                            .Where(b => b.Estado == "Activo")
                            .GroupBy(b => b.IdVueloNavigation.IdAerolineaNavigation.Nombre)
                            .Select(g => new {
                                Aerolinea = g.Key,
                                TotalBoletosVendidos = g.Count(),
                                IngresosTotales = g.Sum(b => b.Precio)
                            })
                            .OrderByDescending(x => x.IngresosTotales)
                            .ToList();
                        dgvResults.DataSource = q7;
                        break;
                    case 8:
                        var q8 = context.Vuelos
                            .Include(v => v.IdAeropuertoOrigenNavigation)
                            .Include(v => v.IdAeropuertoDestinoNavigation)
                            .GroupBy(v => new { 
                                Origen = v.IdAeropuertoOrigenNavigation.Ciudad, 
                                Destino = v.IdAeropuertoDestinoNavigation.Ciudad 
                            })
                            .Select(g => new {
                                RutaOrigen = g.Key.Origen,
                                RutaDestino = g.Key.Destino,
                                VuelosProgramados = g.Count()
                            })
                            .OrderByDescending(x => x.VuelosProgramados)
                            .ToList();
                        dgvResults.DataSource = q8;
                        break;
                    case 9:
                        var q9 = context.Equipajes
                            .Include(e => e.IdBoletoNavigation)
                            .ThenInclude(b => b.IdVueloNavigation)
                            .GroupBy(e => e.IdBoletoNavigation.IdVueloNavigation.CodigoVuelo)
                            .Select(g => new {
                                Vuelo = g.Key,
                                CantidadMaletas = g.Count(),
                                PesoTotalKg = g.Sum(x => x.Peso)
                            })
                            .OrderByDescending(x => x.PesoTotalKg)
                            .Take(50).ToList();
                        dgvResults.DataSource = q9;
                        break;
                    case 10:
                        var q10 = context.Vuelos
                            .Include(v => v.IdAerolineaNavigation)
                            .Include(v => v.IdAeronaveNavigation)
                            .Include(v => v.Boletos)
                            .Select(v => new {
                                Vuelo = v.CodigoVuelo,
                                Aerolinea = v.IdAerolineaNavigation.Nombre,
                                Avion = v.IdAeronaveNavigation.Modelo,
                                CapacidadTotal = v.IdAeronaveNavigation.Capacidad,
                                BoletosVendidos = v.Boletos.Count,
                                RecaudacionVuelo = v.Boletos.Sum(b => b.Precio)
                            })
                            .OrderByDescending(x => x.RecaudacionVuelo)
                            .Take(100).ToList();
                        dgvResults.DataSource = q10;
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error al ejecutar la consulta:\n" + ex.InnerException?.Message ?? ex.Message, 
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            Cursor.Current = Cursors.Default;
        }
    }
}
