﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnJobSeleccion = new System.Windows.Forms.Button();
            this.btnEmployeesSeleccion = new System.Windows.Forms.Button();
            this.dgvPubsAbejitas = new System.Windows.Forms.DataGridView();
            this.btnStoresProyeccion = new System.Windows.Forms.Button();
            this.btnPublisherProyeccion = new System.Windows.Forms.Button();
            this.btnSalesRenombramiento = new System.Windows.Forms.Button();
            this.btnTittleRenombramiento = new System.Windows.Forms.Button();
            this.btnPriceSeleccion = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnTittlesUnion = new System.Windows.Forms.Button();
            this.btnAuthorsUnion = new System.Windows.Forms.Button();
            this.btnStoresUnion = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnEmployeesRenombramiento = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnPublishersDiferencia = new System.Windows.Forms.Button();
            this.btnEmployeesDiferencia = new System.Windows.Forms.Button();
            this.btnJobsDiferencia = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btnAuthorsPC = new System.Windows.Forms.Button();
            this.btnProductoPC = new System.Windows.Forms.Button();
            this.btnDiscountsPC = new System.Windows.Forms.Button();
            this.btnAuthorsProyeccion = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPubsAbejitas)).BeginInit();
            this.SuspendLayout();
            // 
            // btnJobSeleccion
            // 
            this.btnJobSeleccion.Location = new System.Drawing.Point(39, 46);
            this.btnJobSeleccion.Name = "btnJobSeleccion";
            this.btnJobSeleccion.Size = new System.Drawing.Size(75, 51);
            this.btnJobSeleccion.TabIndex = 0;
            this.btnJobSeleccion.Text = "Job (seleccion)";
            this.btnJobSeleccion.UseVisualStyleBackColor = true;
            this.btnJobSeleccion.Click += new System.EventHandler(this.btnJob_Click);
            // 
            // btnEmployeesSeleccion
            // 
            this.btnEmployeesSeleccion.Location = new System.Drawing.Point(130, 46);
            this.btnEmployeesSeleccion.Name = "btnEmployeesSeleccion";
            this.btnEmployeesSeleccion.Size = new System.Drawing.Size(75, 51);
            this.btnEmployeesSeleccion.TabIndex = 1;
            this.btnEmployeesSeleccion.Text = "employees (seleccion)";
            this.btnEmployeesSeleccion.UseVisualStyleBackColor = true;
            this.btnEmployeesSeleccion.Click += new System.EventHandler(this.button2_Click);
            // 
            // dgvPubsAbejitas
            // 
            this.dgvPubsAbejitas.AccessibleRole = System.Windows.Forms.AccessibleRole.DropList;
            this.dgvPubsAbejitas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPubsAbejitas.Location = new System.Drawing.Point(49, 245);
            this.dgvPubsAbejitas.Name = "dgvPubsAbejitas";
            this.dgvPubsAbejitas.Size = new System.Drawing.Size(773, 270);
            this.dgvPubsAbejitas.TabIndex = 2;
            // 
            // btnStoresProyeccion
            // 
            this.btnStoresProyeccion.Location = new System.Drawing.Point(412, 46);
            this.btnStoresProyeccion.Name = "btnStoresProyeccion";
            this.btnStoresProyeccion.Size = new System.Drawing.Size(75, 51);
            this.btnStoresProyeccion.TabIndex = 4;
            this.btnStoresProyeccion.Text = "Store (proyeccion)";
            this.btnStoresProyeccion.UseVisualStyleBackColor = true;
            this.btnStoresProyeccion.Click += new System.EventHandler(this.btnStores_Click);
            // 
            // btnPublisherProyeccion
            // 
            this.btnPublisherProyeccion.Location = new System.Drawing.Point(331, 46);
            this.btnPublisherProyeccion.Name = "btnPublisherProyeccion";
            this.btnPublisherProyeccion.Size = new System.Drawing.Size(75, 51);
            this.btnPublisherProyeccion.TabIndex = 3;
            this.btnPublisherProyeccion.Text = "Publisher (proyeccion)";
            this.btnPublisherProyeccion.UseVisualStyleBackColor = true;
            this.btnPublisherProyeccion.Click += new System.EventHandler(this.btnPublisher_Click);
            // 
            // btnSalesRenombramiento
            // 
            this.btnSalesRenombramiento.Location = new System.Drawing.Point(680, 46);
            this.btnSalesRenombramiento.Name = "btnSalesRenombramiento";
            this.btnSalesRenombramiento.Size = new System.Drawing.Size(75, 51);
            this.btnSalesRenombramiento.TabIndex = 6;
            this.btnSalesRenombramiento.Text = "Sales (renombramiento) ";
            this.btnSalesRenombramiento.UseVisualStyleBackColor = true;
            this.btnSalesRenombramiento.Click += new System.EventHandler(this.btnSales_Click);
            // 
            // btnTittleRenombramiento
            // 
            this.btnTittleRenombramiento.Location = new System.Drawing.Point(599, 46);
            this.btnTittleRenombramiento.Name = "btnTittleRenombramiento";
            this.btnTittleRenombramiento.Size = new System.Drawing.Size(75, 51);
            this.btnTittleRenombramiento.TabIndex = 5;
            this.btnTittleRenombramiento.Text = "Tittle (renombramiento) ";
            this.btnTittleRenombramiento.UseVisualStyleBackColor = true;
            this.btnTittleRenombramiento.Click += new System.EventHandler(this.btnTittle_Click);
            // 
            // btnPriceSeleccion
            // 
            this.btnPriceSeleccion.Location = new System.Drawing.Point(221, 46);
            this.btnPriceSeleccion.Name = "btnPriceSeleccion";
            this.btnPriceSeleccion.Size = new System.Drawing.Size(75, 51);
            this.btnPriceSeleccion.TabIndex = 7;
            this.btnPriceSeleccion.Text = "Price (seleccion) ";
            this.btnPriceSeleccion.UseVisualStyleBackColor = true;
            this.btnPriceSeleccion.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(111, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "consultas de seleccion";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(376, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "consultas de proyeccion";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(94, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "consultas de Union";
            // 
            // btnTittlesUnion
            // 
            this.btnTittlesUnion.Location = new System.Drawing.Point(211, 157);
            this.btnTittlesUnion.Name = "btnTittlesUnion";
            this.btnTittlesUnion.Size = new System.Drawing.Size(75, 51);
            this.btnTittlesUnion.TabIndex = 12;
            this.btnTittlesUnion.Text = "Tittle (union)";
            this.btnTittlesUnion.UseVisualStyleBackColor = true;
            this.btnTittlesUnion.Click += new System.EventHandler(this.btnTittlesUnion_Click);
            // 
            // btnAuthorsUnion
            // 
            this.btnAuthorsUnion.Location = new System.Drawing.Point(130, 157);
            this.btnAuthorsUnion.Name = "btnAuthorsUnion";
            this.btnAuthorsUnion.Size = new System.Drawing.Size(75, 51);
            this.btnAuthorsUnion.TabIndex = 11;
            this.btnAuthorsUnion.Text = "Authors (union)";
            this.btnAuthorsUnion.UseVisualStyleBackColor = true;
            this.btnAuthorsUnion.Click += new System.EventHandler(this.btnAuthorsUnion_Click);
            // 
            // btnStoresUnion
            // 
            this.btnStoresUnion.Location = new System.Drawing.Point(49, 157);
            this.btnStoresUnion.Name = "btnStoresUnion";
            this.btnStoresUnion.Size = new System.Drawing.Size(75, 51);
            this.btnStoresUnion.TabIndex = 10;
            this.btnStoresUnion.Text = "Stores (union)";
            this.btnStoresUnion.UseVisualStyleBackColor = true;
            this.btnStoresUnion.Click += new System.EventHandler(this.btnStoresUnion_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.LightCyan;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(630, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(145, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "consultas de renombramiento";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // btnEmployeesRenombramiento
            // 
            this.btnEmployeesRenombramiento.Location = new System.Drawing.Point(761, 46);
            this.btnEmployeesRenombramiento.Name = "btnEmployeesRenombramiento";
            this.btnEmployeesRenombramiento.Size = new System.Drawing.Size(75, 51);
            this.btnEmployeesRenombramiento.TabIndex = 15;
            this.btnEmployeesRenombramiento.Text = "Employees (renombramiento) ";
            this.btnEmployeesRenombramiento.UseVisualStyleBackColor = true;
            this.btnEmployeesRenombramiento.Click += new System.EventHandler(this.button5_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(382, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "consultas de diferencia";
            // 
            // btnPublishersDiferencia
            // 
            this.btnPublishersDiferencia.Location = new System.Drawing.Point(493, 157);
            this.btnPublishersDiferencia.Name = "btnPublishersDiferencia";
            this.btnPublishersDiferencia.Size = new System.Drawing.Size(75, 51);
            this.btnPublishersDiferencia.TabIndex = 18;
            this.btnPublishersDiferencia.Text = "Publishers (diferencia)";
            this.btnPublishersDiferencia.UseVisualStyleBackColor = true;
            this.btnPublishersDiferencia.Click += new System.EventHandler(this.btnPublishersDiferencia_Click);
            // 
            // btnEmployeesDiferencia
            // 
            this.btnEmployeesDiferencia.Location = new System.Drawing.Point(412, 157);
            this.btnEmployeesDiferencia.Name = "btnEmployeesDiferencia";
            this.btnEmployeesDiferencia.Size = new System.Drawing.Size(75, 51);
            this.btnEmployeesDiferencia.TabIndex = 17;
            this.btnEmployeesDiferencia.Text = "Employees (diferencia)";
            this.btnEmployeesDiferencia.UseVisualStyleBackColor = true;
            this.btnEmployeesDiferencia.Click += new System.EventHandler(this.btnEmployeesDiferencia_Click);
            // 
            // btnJobsDiferencia
            // 
            this.btnJobsDiferencia.Location = new System.Drawing.Point(331, 157);
            this.btnJobsDiferencia.Name = "btnJobsDiferencia";
            this.btnJobsDiferencia.Size = new System.Drawing.Size(75, 51);
            this.btnJobsDiferencia.TabIndex = 16;
            this.btnJobsDiferencia.Text = "Jobs (diferencia)";
            this.btnJobsDiferencia.UseVisualStyleBackColor = true;
            this.btnJobsDiferencia.Click += new System.EventHandler(this.button8_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(630, 129);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "consultas de producto cartesiano";
            // 
            // btnAuthorsPC
            // 
            this.btnAuthorsPC.Location = new System.Drawing.Point(761, 157);
            this.btnAuthorsPC.Name = "btnAuthorsPC";
            this.btnAuthorsPC.Size = new System.Drawing.Size(75, 51);
            this.btnAuthorsPC.TabIndex = 22;
            this.btnAuthorsPC.Text = "Authors (producto cartesiano)";
            this.btnAuthorsPC.UseVisualStyleBackColor = true;
            this.btnAuthorsPC.Click += new System.EventHandler(this.btnAuthorsPC_Click);
            // 
            // btnProductoPC
            // 
            this.btnProductoPC.Location = new System.Drawing.Point(680, 157);
            this.btnProductoPC.Name = "btnProductoPC";
            this.btnProductoPC.Size = new System.Drawing.Size(75, 51);
            this.btnProductoPC.TabIndex = 21;
            this.btnProductoPC.Text = "Producto (producto cartesiano)";
            this.btnProductoPC.UseVisualStyleBackColor = true;
            this.btnProductoPC.Click += new System.EventHandler(this.btnProductoPC_Click);
            // 
            // btnDiscountsPC
            // 
            this.btnDiscountsPC.Location = new System.Drawing.Point(599, 157);
            this.btnDiscountsPC.Name = "btnDiscountsPC";
            this.btnDiscountsPC.Size = new System.Drawing.Size(75, 51);
            this.btnDiscountsPC.TabIndex = 20;
            this.btnDiscountsPC.Text = "Discounts (producto cartesiano)";
            this.btnDiscountsPC.UseVisualStyleBackColor = true;
            this.btnDiscountsPC.Click += new System.EventHandler(this.btnDiscountsPC_Click);
            // 
            // btnAuthorsProyeccion
            // 
            this.btnAuthorsProyeccion.Location = new System.Drawing.Point(493, 46);
            this.btnAuthorsProyeccion.Name = "btnAuthorsProyeccion";
            this.btnAuthorsProyeccion.Size = new System.Drawing.Size(75, 51);
            this.btnAuthorsProyeccion.TabIndex = 24;
            this.btnAuthorsProyeccion.Text = "Authors (proyeccion)";
            this.btnAuthorsProyeccion.UseVisualStyleBackColor = true;
            this.btnAuthorsProyeccion.Click += new System.EventHandler(this.button12_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 548);
            this.Controls.Add(this.btnAuthorsProyeccion);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnAuthorsPC);
            this.Controls.Add(this.btnProductoPC);
            this.Controls.Add(this.btnDiscountsPC);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnPublishersDiferencia);
            this.Controls.Add(this.btnEmployeesDiferencia);
            this.Controls.Add(this.btnJobsDiferencia);
            this.Controls.Add(this.btnEmployeesRenombramiento);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnTittlesUnion);
            this.Controls.Add(this.btnAuthorsUnion);
            this.Controls.Add(this.btnStoresUnion);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnPriceSeleccion);
            this.Controls.Add(this.btnSalesRenombramiento);
            this.Controls.Add(this.btnTittleRenombramiento);
            this.Controls.Add(this.btnStoresProyeccion);
            this.Controls.Add(this.btnPublisherProyeccion);
            this.Controls.Add(this.dgvPubsAbejitas);
            this.Controls.Add(this.btnEmployeesSeleccion);
            this.Controls.Add(this.btnJobSeleccion);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPubsAbejitas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnJobSeleccion;
        private System.Windows.Forms.Button btnEmployeesSeleccion;
        private System.Windows.Forms.DataGridView dgvPubsAbejitas;
        private System.Windows.Forms.Button btnStoresProyeccion;
        private System.Windows.Forms.Button btnPublisherProyeccion;
        private System.Windows.Forms.Button btnSalesRenombramiento;
        private System.Windows.Forms.Button btnTittleRenombramiento;
        private System.Windows.Forms.Button btnPriceSeleccion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnTittlesUnion;
        private System.Windows.Forms.Button btnAuthorsUnion;
        private System.Windows.Forms.Button btnStoresUnion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnEmployeesRenombramiento;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnPublishersDiferencia;
        private System.Windows.Forms.Button btnEmployeesDiferencia;
        private System.Windows.Forms.Button btnJobsDiferencia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnAuthorsPC;
        private System.Windows.Forms.Button btnProductoPC;
        private System.Windows.Forms.Button btnDiscountsPC;
        private System.Windows.Forms.Button btnAuthorsProyeccion;
    }
}

